/** 
* @file APP JS Lab 2: Selection and Loops 
* @author Tim Orman
* @author Suzy Atfield-Cutts
* @version 2021
* @description JS file containing functions for students to complete. Fill in the blanks.
*/
//Try writing code with strict mode on and off (comment it out).
"use strict";


/** @function workoutTax001() - write code in this function that takes the salary 
 * amount as a parameter, and calculates the tax payable at a rate of 30%. If 
 * the salary is over £45000 add an extra £5000 to the tax. Subtract the tax from 
 * the original salary to get the net salary amount. The function should return an 
 * array containing the total amount of tax at index 0 and the net salary at index 1.
 * @param	{number}   numSalary 	amount of salary as a number
 * @return	{number[]} array containing the total amount of tax at index 0 and 
 * 						the net salary at index 1.
*/
function workoutTax001(numSalary) {
	const taxRate = .3;
	let extra = 0;   //I'm using let but could use var instead
	let netSalary = 0;
	let tax = 0;
	let totalTax = 0;
	let arrReturn = [0, 0];

	if (numSalary > 45000) {
		extra = 5000;
	}

	tax = numSalary * taxRate;
	totalTax = tax + extra;
	netSalary = numSalary - totalTax;

	//console.log("Total tax = "+totalTax);
	//console.log("Net paid = "+netSalary);

	arrReturn[0] = totalTax;
	arrReturn[1] = netSalary;

	return arrReturn;
}


/** @function calculateTax001() - write code in this function to prompt a user to enter 
 * their salary. Call the workoutTax001 function to calculate the total tax and 
 * net salary. Display the results in an alert message to the user. 
 * NOTE: This function is not tested, it just provides user interaction. 
 * i.e.: DONT FORGET to call the function!!
*/
function calculateTax001() {
	let salary = prompt("Please enter your salary:");

	//call the calcTax001 function to run it! 
	let salaryArray = workoutTax001(salary);
	alert("Your GROSS salary: " + salary + " Your tax:" + salaryArray[0] + " Your NET salary:" + salaryArray[1]);
}
calculateTax001(); //Dont forget to call the function


/** @function workoutTax002() - write code in this function to take salary amount 
 * as a parameter. Calculate the tax payable at a rate of 30% if the salary is less 
 * than £45000. Calculate the tax at a rate of 50% if the salary is £45000 or more. 
 * The function should return an array containing the total amount of tax at index 0 
 * and the net salary at index 1.
 * @param  {number}   numSalary amount of salary as a number
 * @return {number[]} array containing the total amount of tax at index 0 and 
 * 						the net salary at index 1.
*/
function workoutTax002(numSalary) {
	const taxRate1 = .3;
	const taxRate2 = .5;
	let netSalary = 0;
	let tax = 0;
	let totalTax = 0;
	let arrReturn = [0, 0]; //or var arrReturn=[]; and push() values later

	if (numSalary >= 45000) {
		tax = numSalary * taxRate2;
	} else {
		tax = numSalary * taxRate1;
	}

	netSalary = numSalary - tax;

	//console.log("Total tax = "+totalTax);
	//console.log("Net paid = "+netSalary);

	arrReturn[0] = tax;
	arrReturn[1] = netSalary;

	return arrReturn;
}


/** @function workoutTax003() - write code in this function to take the salary 
 * amount as a parameter, and calculate payable tax at rates of:
 *  - 15% if salary is below £30000
 *  - 30% if salary is in the range from £30000 up to but below £45000
 *  - 50% if salary is £45000 or more. 
 * It should return an array containing the total amount of tax at index 0 
 * and the net salary at index 1.
 * @param  {number}   numSalary amount of salary as a number
 * @return {number[]} array containing the total amount of tax at index 0 and 
 * 						the net salary at index 1.
*/
function workoutTax003(numSalary) {

	const taxRate1 = .15;
	const taxRate2 = .3;
	const taxRate3 = .5;

	let netSalary = 0;
	let tax = 0;
	let totalTax = 0;
	let arrReturn = [0, 0];

	if (numSalary >= 45000) {
		tax = numSalary * taxRate3;
	} else if ((numSalary >= 30000)) {
		tax = numSalary * taxRate2;
	} else {
		tax = numSalary * taxRate1;
	}

	netSalary = numSalary - tax;

	//console.log("Total tax = "+totalTax);
	//console.log("Net paid = "+netSalary);

	arrReturn[0] = tax;
	arrReturn[1] = netSalary;

	return arrReturn;
}


/** @function checkSwitch() - write code in this function to use a switch statement 
 * to return a message based on the number passed in:
 *  1 - returns "SNAP"
 *  2 - returns "CRACKLE"
 *  3 - returns "POP"
 *  4 - returns "EXIT"
 *  default - "DEFAULT"
 * @param  {number} numChoice message selector as a number
 * @return {string}	message to be returned (determined by value of parameter)
*/
function checkSwitch(numChoice) {

	var msgReturn = "";
	switch (numChoice) {
		case 1: msgReturn = "SNAP";
			break;
		case 2: msgReturn = "CRACKLE";
			break;
		case 3: msgReturn = "POP";
			break;
		case 4: msgReturn = "EXIT";
			break;
		default: msgReturn = "DEFAULT";

	}
	return msgReturn;
}

/** @function whileLoop() - write code in this function to remove all the elements 
 * beyond the 5th element from the array (which is passed in to the function as a 
 * parameter). 
 * @param  {*[]} arrToProcess the original array to be processed
 * @return {*[]} an array which is a copy of the first 5 elements of the original.
*/
function whileLoop(arrToProcess) {
	
	while (arrToProcess.length > 5) {
		arrToProcess.pop();
	}

	return arrToProcess;
}

/** @function doLoop() - write code in this function to return an array filled with 
 *  numbers ordered consecutively from 1, up to and including, the value of the 
 *  parameter (numElements).
 *  @param	{number}   numElements number of elements to be stored in the array
 *  @return {number[]} an array which contains numbers from 1 to numElements in order.
*/
function doLoop(numElements) {
	let numCounter = 1;
	let arrToProcess = [];
	//use passed array as we want to shorten the passed array
	do {
		arrToProcess.push(numCounter);
		//or arrToProcess[numCounter-1]=numCounter; but push() is better practise
		numCounter++;
	} while (numCounter <= numElements)
	return arrToProcess;
}

/** @function forLoop() - write code in this function to iterate through the array
 *  and to add 1 to each numeric element of the array (which is passed in as a parameter).
 * NOTE: In the first test: The array contains only numeric elements. 
 * However, in the second test: The array contains some numeric elements, and some 
 * non-numeric elements. 
 * HINT:the typeof operator might come in handy! 
 * 		https://www.w3schools.com/js/js_type_conversion.asp
 * @param  {*[]} arrToProcess 	array to be processed
 * @return {*[]} array after processing, with the value of all numerical 
 * 							elements being 1 greater than in the original array.
*/
function forLoop(arrToProcess) {

	let i;
	//console.log("for loop");
	//loop through array
	for (i = 0; i < arrToProcess.length; i++) {
		//console.log(typeof(arrToProcess[i]));
		// check for a numeric value

		if (typeof arrToProcess[i]  == "number"){ //operator
		//if (typeof (arrToProcess[i]) == "number") { //function style
			//console.log("A number was found.");
			arrToProcess[i]++;
		}
	}
	return arrToProcess;
}


/** @function splitString() - write code in this function to process the parameter. 
 *  The parameter is a comma separated string of words. Call a function to split  
 *  the words of the comma searated string, and place each piece into an element 
 *  of the array, and return the array. 
 *  Then use a loop to add an order number followed by a "." in front of each 
 *  element item e.g. "1.Dog" (no space). 
 *  Which loop should you use? See the lecture slides (Going loopy) 
 *  to help you select the best type of loop to use.
 *  @param	{string}   arrToProcess 	comma separated string of words
 *  @return	{string[]} array of strings
*/
function splitString(arrToProcess) {

	//counter
	let items;
	let numOrder = 0;
	//split elements into an array
	let arrProcessed = arrToProcess.split(",");
	//loop through array and update value of elements. 
	for (items in arrProcessed) {
		numOrder = Number(items) + 1;
		//console.log(numOrder);
		arrProcessed[items] = numOrder + "." + arrProcessed[items];
	}
	//return processed array
	return arrProcessed;
}
//console.log(splitString("one,two,three,four"));

/** @function displayObject() - write code in this function to print out the 
 * contents of the object which is passed in as a parameter. Use a loop 
 * to complete the task (rather than casting the object to a string). 
 * Which loop should you be using for iterating through objects?
 *  @param	{object}  objInventor object containing data about a person who 
 * 					  is an inventor of a programming language.
 *  @return	{string}  String representing an Object
*/
function displayObject(objInventor) {
	
	let output = "";
	let attribute;
	for (attribute in objInventor) {
	  output += objInventor[attribute] + " ";
	}
	output = output.trim();
	//console.log(output);
	return output;
}


/** @function makeString() - write code in this function to concatenate the elements 
 *  of an array (parameter) into a string, and return the new string. 
 *  Put a space between each element (string) in the return string. 
 *  The sentence should start with a capital letter and end with a full stop.
 *  @param	{string[]} arrToProcess array of strings
 *  @return {string}   formatted string
*/
function makeString(arrToProcess) {
	//counter
	let items;
	let strReturn = "";

	//loop through array and concatenate string
	for (items of arrToProcess) {
		strReturn = strReturn + " " + items;
	}
	strReturn = strReturn + ".";

	strReturn = strReturn.charAt(1).toUpperCase() + strReturn.slice(2); //charAt(1) because of space
	//OR (Students have used substring() method in java and might opt for that)
	//strReturn=strReturn.trim();
	//strReturn=strReturn.substring(0, 1).toUpperCase() + strReturn.substring(1);

	//return processed array
	return strReturn;
}


/** @function makeString2() - write code in this function to concatenate the 
 *  elements of the array (passed in as a parameter) into a string, and return 
 *  the new string. Put a space between each element in the return string. 
 *  If none of the punctuation marks in the second array (parameter)
 *  are found at the end of the string, add a full stop at the end of the string.
 *  If punctuation is found at the end of the string remove any spaces before it 
 *  eg: so that "the sentence !" becomes "the sentence!".
 *  @param	{string[]} arrToProcess 	array of strings
 * 	@param	{string[]} arrPunctMarks	array of puntuation marks
 *  @return {string}   reformatted string
*/
/* A couple of versions follow....*/

function makeString2(arrToProcess, arrPunctMarks){
	//counter
	let items;
	let strReturn = "";
	let strPunct;
	let numStrPosition;

	//loop through array and concatenate string
	for(items of arrToProcess){
		strReturn = strReturn + " " + items;
	}
	//get strReturn length
	numStrPosition = strReturn.length - 2;
	//check for punctuation marks already present
	//strPunct = strReturn.charAt(strReturn.length-1); // or......
	strPunct = strReturn.slice(-1);
	//console.log(strReturn.charAt(numStrPosition));
	if(arrPunctMarks.includes(strPunct) == false){
		strReturn = strReturn + ".";
	} else if(strReturn.charAt(numStrPosition) == " "){ 
		//console.log("space found");
		//remove space - result of adding a space!
		strReturn = strReturn.substring(0,numStrPosition) + strReturn.substring(numStrPosition+1,strReturn.length)
	}
	//make first char uppercase
	strReturn = strReturn.charAt(1).toUpperCase() + strReturn.slice(2);
	//return processed array
	return strReturn;
}

/*
function makeString2(arrToProcess, arrPunctMarks){
	
	let item;
	let strReturn = "";
	let strLastLetter;

	//loop through array and concatenate string
	for(item of arrToProcess){
		strReturn = strReturn + " " + item;
	}
	strReturn=strReturn.trim(); //remove space on front and end of string
	
	//check for punctuation marks on end
	var indexOfLastLetter= strReturn.length - 1
	strLastLetter = strReturn.substring(indexOfLastLetter);
	if(arrPunctMarks.includes(strLastLetter)==false){
		strReturn = strReturn + ".";
	} 
	//apparently test is written to look for spaces before puntuation as well
	//this removes that white space
	else if (strReturn.substring(indexOfLastLetter-1, indexOfLastLetter)==" "){
		//get copy of punctuation - save "!" from "words !"
		var strPunctuation = strReturn.substring(indexOfLastLetter);
		//save string up to and not including final puntuation - "word "
		strReturn = strReturn.substring(0, strReturn.length-1);
		//trim space off and stick punctuation back on - "word!"
		strReturn = strReturn.trim() + strPunctuation;
	}
	//make first char uppercase and concat with rest of string
	strReturn=strReturn.substring(0, 1).toUpperCase() + strReturn.substring(1);
	//return processed array
	return strReturn;
}
*/

/***********************************************************************/
/** ADVANCED TASKS ONLY BEYOND THIS POINT                              */
/***********************************************************************/
/** @function advancedFunction() - NOT TESTED. 
 * 	write code in this function to get the user to input between 3 and 6 numbers.
 *  Then use these numbers to select words from a list of words 
 *  eg: arrWordList = ["once", "upon", "a", "car", "boat", "train", "tree", "bird", "cat", "elephant", "their", "mine"]; 
 *  and make a 'sentence' (String) with them. The first letter of a sentence 
 *  should be uppercase and a full stop should be added to the end. Syntax and 
 *  meaning is not important. The function should use the length of the list of 
 *  words to help prompt users avoid putting in values higher than the last word  
 *  the list. 
**/
/* uncomment to use
function advancedFunction(){
	let strInput = "";
	let items;
	let strReturn = "";
	let arrInputValues = [];
	let boolValidInput = true;
	const arrWordList = ["once", "upon", "a", "car", "boat", "train", "tree", "bird", "cat", "elephant", "their", "mine"];
	const numListLength = arrWordList.length-1;

	//get user input
	strInput = prompt("Enter a comma separated list of numbers ranging between 0 and " + numListLength);
	
	//split out values
	arrInputValues = strInput.split(",");
	console.log(arrInputValues);
	
	//FOR EVEN MORE ADVANCED:
	//check for values over the max allowed
	//use a loop nested inside a do-while to go through array
	//to validate the inputs are within range
	//That way you can give the user the oppotunity to enter different values
	//OR
	for (const items of arrInputValues) { 
		//console.log(items);
		if((items<0)||(items>numListLength)){
			//console.log(items + " is not a valid input");
			boolValidInput = false;
		}
	}
	if(boolValidInput==true){
		//loop through array and concatenate string
		for(items of arrInputValues){
			strReturn = strReturn + " " + arrWordList[items];
		}
		//add punctuation
		strReturn = strReturn + ".";
		//make first char uppercase
		strReturn = strReturn.charAt(1).toUpperCase() + strReturn.slice(2);
		//console.log(strReturn);
	} else {
		strReturn = "You enterred an invalid number i.e. subzero or higher than " + numListLength;
	}
	alert(strReturn);
	console.log(strReturn);
	//return strReturn; 
}
//advancedFunction();

/*
/** @function checkSwitchAdvanced() - NOT TESTED
 * Just like in checkSwitch() function - write code in this function to use a
 * switch statement return a message based on the passed number:
 * This time ...
 *  1 - returns "SNAP CRACKLE POP"
 *  2 - returns "CRACKLE POP"
 *  3 - returns "POP"
 *  4 - returns "EXIT"
 *  default - "DEFAULT"
 * REMEMBER THE DRY PRINCIPLE - You can only use the words 'SNAP' 'CRACKLE' and
 * 'POP' once in the code.
 * You need to call the function to run it.
 * The function calls are below the function with a variety of values for testing.
 * Just remove the comments notation when you are ready to test.
*/
/*
function checkSwitchAdvanced(numChoice){

	var  msgReturn="";
	switch(numChoice)
	{
		case 1: msgReturn="SNAP";
		case 2: msgReturn=msgReturn+"CRACKLE";
		case 3: msgReturn=msgReturn+"POP";
				break;
		case 4: msgReturn="EXIT";
				break;
		default: msgReturn="DEFAULT";

	}
	alert(msgReturn);
}
*/

//checkSwitchAdvanced(1);
//checkSwitchAdvanced(2);
//checkSwitchAdvanced(4);
//checkSwitchAdvanced(111);